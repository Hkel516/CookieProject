#ifndef TESTING_H
#define TESTING_H

#include "CookieList.h"
#include "CookieDB.h"

const size_t TOTAL_COOKIES = 12;

void createCookieList(CookieList& cookieList);

#endif
