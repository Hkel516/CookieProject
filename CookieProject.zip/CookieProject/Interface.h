/*
    Kelley, Hayden

    CS A250
    Project (Part C)
*/

#ifndef INTERFACE_H
#define INTERFACE_H

#include "CookieList.h"

void displayMenu();
void processChoice(CookieList& cookieList);

#endif